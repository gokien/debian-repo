# gokien-default-settings

This package overrides [`elementary-default-settings`](https://code.launchpad.net/~elementary-os/elementaryos/default-settings-luna).
